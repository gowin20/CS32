#ifndef game_h
#define game_h

#include "Arena.h"

class Game
{
public:
	// Constructor/destructor
	Game(int rows, int cols, int nZombies);
	~Game();

	// Mutators
	void play();

private:
	Arena* m_arena;
};

#endif // !game_h
