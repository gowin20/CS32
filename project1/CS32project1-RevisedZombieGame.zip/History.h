#ifndef history_h
#define history_h

#include "globals.h"
class History
{
	public:
		History(int nRows, int nCols);
		bool record(int r, int c);
		void display() const;
	private:
		int m_hisrows; //used to display and check for validity
		int m_hiscols; // ^
		char m_deathlist[MAXROWS][MAXCOLS]; //the actual grid which records the history of things.
};
#endif // !history_h
