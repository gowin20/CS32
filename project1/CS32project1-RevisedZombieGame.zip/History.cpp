#include "History.h"
using namespace std;

History::History(int nRows, int nCols)
{
	m_hisrows = nRows; //initialize to arena size
	m_hiscols = nCols;
	for (int i = 0; i < nRows; i++)
	{
		for (int j = 0; j < nCols; j++)
		{
			m_deathlist[i][j] = '.'; //nothing is dead yet
		}
	}
}

bool History::record(int r, int c)
{
	if (r > m_hisrows || c > m_hiscols) //check for valid input
		return false;
	char& hischar = m_deathlist[r - 1][c - 1]; //minus one to convert to arena coordinate system, where 1,1 is the upper left
	switch (hischar)
	{
	case '.':
		hischar = 'A'; //A is 1 death, B is 2, up to Z being 26. Anything above 26 is also Z
		break;
	case 'Z':
		break;
	default:
		hischar++;
	}
	return true;
}

void History::display() const //clears the screen and prints the deathlist, then a newline
{
	clearScreen();
	for (int r = 0; r < m_hisrows; r++)
	{
		for (int c = 0; c < m_hiscols; c++) 
			cout << m_deathlist[r][c];
		cout << endl;
	}
	cout << endl;
}